export default {
  'appName': 'brugaMusic',
  'apiKey': '1b44360cc775726f390e85afc14d8747',
  'sharedSecret': '38524ed9afd088fb72194c72f86802ac',
  'registeredTo': 'brugarolas',
  'url': 'https://ws.audioscrobbler.com/2.0/'
};
