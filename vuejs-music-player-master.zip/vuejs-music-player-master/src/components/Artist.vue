<template>
  <v-layout row>
    <v-flex xs12 sm6 offset-sm3>
      <v-card>
        
      </v-card>
    </v-flex>
  </v-layout>
</template>

<script>

export default {
  name: 'Artist',
  data () {
    return {
      items: []
    }
  }
}
</script>