# bruga-music

> Music app made with Vue, Vuex and Vue Router

> [Try it here!](https://brugarolas.github.io/bruga-music/)

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run start

# build for production with minification
npm run build
```
